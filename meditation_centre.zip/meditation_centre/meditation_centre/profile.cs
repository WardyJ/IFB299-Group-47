using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

namespace meditation_centre
{
    [Activity(Label = "My Profile")]
    public class profile : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            string studentIDText = Intent.GetStringExtra("studentID");

            MySqlConnection con = new MySqlConnection("Server=stevie.heliohost.org;Port=3306;database=team47_meditationcentre;User Id=team47;Password=rolav1;charset=utf8");

            //string userFullName = "";

            /*if (con.State == ConnectionState.Closed)
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM students WHERE StudentID = @studentID)", con);
                cmd.Parameters.AddWithValue("@studentID", Int32.Parse(studentIDText));
                cmd.ExecuteNonQuery();
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int StudentID = reader.GetInt32(0);
                    userFullName = reader.GetString(1);

                    con.Close();
                }
            }*/


            //FindViewById<TextView>(Resource.Id.prfFullName).Text = studentIDText;

            SetContentView(Resource.Layout.profile);
        }
    }
}