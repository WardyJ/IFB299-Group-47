﻿using System;
using Xamarin.Forms;

namespace MySQL_Demo
{
	public class App : Application
	{
		public App ()
		{
			MainPage = new ButtonXamlPage();
		}
	}
}
