using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MySql.Data.MySqlClient;
using System.Data;

namespace meditation_centre
{
    [Activity(Label = "Edit Profile")]
    public class editprofile : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.profile);
            string studentIDText = Intent.GetStringExtra("studentID");

            //MySqlConnection con = new MySqlConnection("Server=stevie.heliohost.org;Port=3306;database=team47_meditationcentre;User Id=team47;Password=rolav1;charset=utf8");
            MySqlConnection con = new MySqlConnection("Server=sql6.freesqldatabase.com;Port=3306;database=sql6136440;User Id=sql6136440;Password=Q3w7IWjPNS;charset=utf8");
        }
    }
}